#!/usr/bin/bash

# The only command line argument is a file name
file_name=$1

# Iterate over each line of the input file
while IFS= read -r line; do
    # Here's where you can use regex capture groups to extract the info from each line
    # You'll need to capture two pieces of data: the field name and the value of the field.
    # Put your regex with capture groups to the right of the =~ operator
    if [[ $line =~  ]]; then
        # Recall how to access text from regex capture groups
        # See slide 15 from the lecture
        field=?
        value=?
    else
        # If nothing could be extraced, then skip the line
        continue
    fi

    case $field in
        # You can follow this pattern for all other fields
        email) # Case where the field name is literally the string "email"
            # Same regex for email that we used in lecture
            pattern='^[[:alnum:]_#-]+@[[:alnum:]-]+\.[[:alnum:]]{2,4}$'
            ;;
        *) # Case where there the field name didn't match anything
            continue
            ;;
    esac


    if ! [[ $value =~ $pattern ]]; then
        # We need to print out a message if the field isn't valid
    fi
        
done < "$file_name"

# We need to print something if all fields were valid
# Remember, booleans are useful for this assignment
if [[ $passed = true ]]; then
    exit 0
fi
